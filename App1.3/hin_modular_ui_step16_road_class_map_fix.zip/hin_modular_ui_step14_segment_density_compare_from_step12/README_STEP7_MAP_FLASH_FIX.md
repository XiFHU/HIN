# Step 7 - Map Flash Fix

This update fixes the grey/flashing map panel issue.

Cause: several workflow steps created Folium maps during the same Streamlit rerun. The app was rendering each map immediately into the same right-side placeholder, so users saw the info box or grey map area flash before the final map appeared.

Fix: workflow steps now queue the latest Folium map. The app renders only one map after the left workflow finishes.

No analysis modules were changed.
