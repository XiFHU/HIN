# Step 15 - Sticky map, HIN comparison layers, optional road class styling

This package is based on the user-uploaded Step 14 package.

## Updates

1. Final Segment HIN risk map now supports additional comparison layers:
   - Risk Segments
   - Risk Corridors
   - Original Crash Density
   - Current Spatial Units / Crash Density
   - Crashes
   - Signals
   - Corridors
   - Roads

2. The map panel is kept fixed/sticky on the right side of the app.
   - Only the left workflow panel scrolls.
   - The map remains visible while working in lower workflow sections.

3. Major workflow sections are folded by default.
   - Road Network
   - OSM Signals
   - Corridors
   - Crash Data
   - Classification / Results
   - Sliding Window Risk Analysis

4. Road Network now includes an optional folded section:
   - Optional: road class/type map styling
   - Users can select a road class/type column from uploaded data.
   - Users can choose which classes/types to visualize on the map.
   - This only affects map display; the full road network remains available for analysis.

5. When using uploaded existing segments in Section 7, the Segment Length input is hidden because uploaded segment lengths come from the road geometry.
