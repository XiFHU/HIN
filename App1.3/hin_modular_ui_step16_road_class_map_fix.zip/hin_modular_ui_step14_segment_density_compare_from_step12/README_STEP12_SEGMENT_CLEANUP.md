# Step 12 Segment Workflow Cleanup

Changes:

1. Removed the extra Corridor Context Map from the Segment / Sliding Window workflow.
2. Removed the left-panel Layer Controls that were still appearing after the Segment results.
3. Added a compact Metric definitions expander under the Sliding Window Risk Metric selector.

Metric definitions:

- Crash Count: total crashes in each sliding window.
- Crash Density: crashes per mile.
- EPDO: severity-weighted crash score using K/A/B/C/O weights.
- EPDO Density: severity-weighted crash score per mile.

Corridor and Intersection workflows were not changed.
