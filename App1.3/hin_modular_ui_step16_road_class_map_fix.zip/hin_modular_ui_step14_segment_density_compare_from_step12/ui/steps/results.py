"""Step 6 results tables plus orchestration for classification and downloads."""

from .classification import render_classification_step
from .downloads import render_results_downloads


def add_density_to_spatial_units(spatial_units_map, np):
    spatial_units_map = spatial_units_map.copy()
    spatial_units_proj = spatial_units_map.to_crs(epsg=3857)

    spatial_units_map["Length_Miles"] = spatial_units_proj.geometry.length / 1609.344
    spatial_units_map["Area_SqMi"] = spatial_units_proj.geometry.area / 2589988.110336
    spatial_units_map["CrashDensity"] = 0.0

    if "UnitType" in spatial_units_map.columns:
        line_mask = spatial_units_map["UnitType"].isin(
            ["Segment", "Corridor", "Sliding Window", "Road Segment"]
        )
        area_mask = spatial_units_map["UnitType"].isin(
            ["Intersection", "Intersection Buffer"]
        )

        spatial_units_map.loc[line_mask, "CrashDensity"] = np.where(
            spatial_units_map.loc[line_mask, "Length_Miles"] > 0,
            spatial_units_map.loc[line_mask, "CrashCount"]
            / spatial_units_map.loc[line_mask, "Length_Miles"],
            0,
        )

        spatial_units_map.loc[area_mask, "CrashDensity"] = np.where(
            spatial_units_map.loc[area_mask, "Area_SqMi"] > 0,
            spatial_units_map.loc[area_mask, "CrashCount"]
            / spatial_units_map.loc[area_mask, "Area_SqMi"],
            0,
        )

        other_mask = ~(line_mask | area_mask)
        spatial_units_map.loc[other_mask, "CrashDensity"] = spatial_units_map.loc[
            other_mask,
            "CrashCount",
        ]
    else:
        geom_types = spatial_units_map.geometry.geom_type
        line_mask = geom_types.isin(["LineString", "MultiLineString"])
        polygon_mask = geom_types.isin(["Polygon", "MultiPolygon"])
        point_mask = geom_types.isin(["Point", "MultiPoint"])

        spatial_units_map.loc[line_mask, "CrashDensity"] = np.where(
            spatial_units_map.loc[line_mask, "Length_Miles"] > 0,
            spatial_units_map.loc[line_mask, "CrashCount"]
            / spatial_units_map.loc[line_mask, "Length_Miles"],
            0,
        )

        spatial_units_map.loc[polygon_mask, "CrashDensity"] = np.where(
            spatial_units_map.loc[polygon_mask, "Area_SqMi"] > 0,
            spatial_units_map.loc[polygon_mask, "CrashCount"]
            / spatial_units_map.loc[polygon_mask, "Area_SqMi"],
            0,
        )

        spatial_units_map.loc[point_mask, "CrashDensity"] = spatial_units_map.loc[
            point_mask,
            "CrashCount",
        ]

    spatial_units_map["CrashDensity"] = (
        spatial_units_map["CrashDensity"]
        .replace([np.inf, -np.inf], 0)
        .fillna(0)
    )

    return spatial_units_map


def make_density_colormap(gdf, pd, cm, density_col="CrashDensity"):
    values = pd.to_numeric(gdf[density_col], errors="coerce").fillna(0)
    vmax = values.quantile(0.95)

    if vmax <= 0:
        vmax = 1

    cmap = cm.LinearColormap(
        colors=["green", "yellow", "orange", "red"],
        vmin=0,
        vmax=float(vmax),
    )
    cmap.caption = "Crash Density: Green = Low, Red = High"

    return cmap


def render_results_step(st_folium, workflow_context, spatial_unit=None):
    globals().update(workflow_context)

    route_col = st.session_state.get("route_col", "FULLNAME")
    segment_id_col = st.session_state.get("segment_id_col", None)

    render_classification_step(
        workflow_context=workflow_context,
        spatial_unit=spatial_unit,
    )

    spatial_units = st.session_state.get("spatial_units", None)
    assigned_crashes = st.session_state.get("assigned_crashes", None)
    kabco_result = st.session_state.get("kabco_result", None)
    analysis_type = st.session_state.get("analysis_type", None)

    if spatial_units is None or assigned_crashes is None:
        st.info("Classify crashes first to generate results.")
        return

    crash_counts = (
        assigned_crashes
        .groupby("UnitID")
        .size()
        .reset_index(name="CrashCount")
    )

    spatial_units_map = spatial_units.merge(
        crash_counts,
        on="UnitID",
        how="left",
    )

    spatial_units_map["CrashCount"] = (
        spatial_units_map["CrashCount"]
        .fillna(0)
        .astype(int)
    )

    spatial_units_map = add_density_to_spatial_units(spatial_units_map, np)

    st.subheader(f"{analysis_type} Spatial Units")

    units_table = spatial_units_map.copy()
    units_table["GeometryType"] = units_table.geometry.geom_type

    raw_display_unit_cols = [
        "UnitType",
        "UnitID",
        "IntersectionID",
        "SegmentID",
        "CorridorID",
        "Route",
        route_col,
        segment_id_col,
        "FULLNAME",
        "RoadName1",
        "RoadName2",
        "FromMile",
        "ToMile",
        "Length_Miles",
        "Area_SqMi",
        "CrashCount",
        "CrashDensity",
        "GeometryType",
    ]

    display_unit_cols = []
    for c in raw_display_unit_cols:
        if c is not None and c in units_table.columns and c not in display_unit_cols:
            display_unit_cols.append(c)

    units_table = units_table[display_unit_cols]

    st.dataframe(units_table, width="stretch")

    st.subheader("Assigned Crashes")

    assigned_table = assigned_crashes.copy()
    assigned_table["Latitude"] = assigned_table.geometry.y
    assigned_table["Longitude"] = assigned_table.geometry.x

    raw_display_crash_cols = [
        "CrashID",
        "SourceCrashID",
        "UnitType",
        "UnitID",
        "IntersectionID",
        "SegmentID",
        "CorridorID",
        "Route",
        route_col,
        segment_id_col,
        "FULLNAME",
        "Latitude",
        "Longitude",
        "DistToUnit_M",
        "KABCO",
        "kabco",
        "Severity",
        "severity",
        "CRASH_SEVERITY",
        "Crash Severity",
        "INJURY_SEVERITY",
        "injury_severity",
    ]

    display_crash_cols = []
    for c in raw_display_crash_cols:
        if c is not None and c in assigned_table.columns and c not in display_crash_cols:
            display_crash_cols.append(c)

    assigned_table = assigned_table[display_crash_cols]

    st.dataframe(assigned_table, width="stretch")

    if kabco_result is not None:
        st.subheader("KABCO / Crash Summary")
        st.dataframe(kabco_result, width="stretch")

    density_cmap = make_density_colormap(spatial_units_map, pd, cm)

    render_results_downloads(
        st_folium=st_folium,
        workflow_context=workflow_context,
        spatial_units_map=spatial_units_map,
        units_table=units_table,
        assigned_table=assigned_table,
        assigned_crashes=assigned_crashes,
        kabco_result=kabco_result,
        analysis_type=analysis_type,
        density_cmap=density_cmap,
    )
