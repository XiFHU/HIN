Step 3: Workflow files separated by spatial unit.

New files:
  ui/intersection.py
  ui/corridor.py
  ui/segment.py
  ui/workflow_shared.py

What changed:
  - ui/workflows.py is now only a dispatcher.
  - Each top tab has its own workflow entry file.
  - The large shared implementation is still in workflow_shared.py so the app keeps running.

Next recommended refactor:
  Create ui/steps/ and move shared functions there:
    ui/steps/roads.py
    ui/steps/signals.py
    ui/steps/corridors.py
    ui/steps/crashes.py
    ui/steps/results.py
    ui/steps/sliding_window.py
