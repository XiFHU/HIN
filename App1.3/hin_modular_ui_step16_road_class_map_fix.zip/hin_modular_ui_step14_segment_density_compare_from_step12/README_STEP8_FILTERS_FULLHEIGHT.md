# Step 8 updates

- Crash data filters are limited to three compact filters: Year, KABCO, and Crash Type.
- The main Folium map is forced to fill the available browser height using CSS and a 900px render height fallback.
- Step-level map calls were updated to use 900px height, and the app-level map queue renders only one map per rerun.
