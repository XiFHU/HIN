# Step 14 Segment density comparison update

Based on the uploaded `hin_modular_ui_step12_segment_cleanup.zip`.

Changes:

1. Sliding Window Risk Metric now only offers:
   - Crash Count
   - EPDO

2. Removed Sliding Window metric options:
   - Crash Density
   - EPDO Density

3. Added a final Segment Comparison Map after the risk segment and risk corridor tables.

4. The final comparison map supports these selectable layers:
   - Original Crash Density
   - Risk Segments
   - Risk Corridors
   - Crashes

5. The original crash-density layer is calculated from the selected/uploaded road network before the sliding-window risk result is displayed, so it can be visually compared against the final HIN risk segments.
