# Step 11 - Signalized intersection only

This update removes the road-geometry intersection inventory workflow.

Intersection analysis now uses the original signal-based process:

1. Upload/select road network.
2. Generate cleaned OSM traffic signals.
3. Upload crash data.
4. Classify **Signalized Intersection Crashes** using signal buffers.
5. View tables, downloads, and map layers.

Removed from the UI/package:

- `ui/steps/intersections.py`
- `modules/intersections.py`
- Road-geometry intersection generation.
- Signalized/non-signalized visualization options.

Important naming change:

- Headings and buttons now explicitly say **Signalized Intersection** so users understand that non-signalized intersections are not included.
