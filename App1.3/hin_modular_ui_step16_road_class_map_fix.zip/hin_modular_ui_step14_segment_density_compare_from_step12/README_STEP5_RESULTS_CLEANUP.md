# Step 5 Results Cleanup

This version splits the old `ui/steps/results.py` into three focused files:

```text
ui/steps/classification.py
ui/steps/results.py
ui/steps/downloads.py
```

## New responsibilities

### `ui/steps/classification.py`
Handles Step 5:
- intersection crash classification
- corridor crash classification
- road segment crash classification
- spatial unit creation
- assigned crashes
- KABCO summary creation

### `ui/steps/results.py`
Handles Step 6 tables and orchestration:
- spatial unit crash counts
- crash density calculation
- spatial unit table
- assigned crash table
- KABCO table
- calls the downloads/map renderer

### `ui/steps/downloads.py`
Handles Step 6 downloads and map output:
- CSV downloads
- GeoJSON export
- PDF map download
- selected layer ZIP download
- crash assignment map rendering

## What did not change

No files in `modules/` were changed. Backend analysis logic remains the same.
