# Step 6 compact UI update

This update applies the requested UI cleanup:

1. Removed visible step numbering from workflow section headers.
   - Example: `Step 4: Upload Crash Data` is now `Crash Data`.

2. Reduced font sizes and vertical spacing.
   - Smaller title/header text.
   - Smaller widget labels.
   - Smaller upload boxes and buttons.
   - Shorter top header.
   - Main map height increased.

3. Moved layer control onto the Folium map.
   - Removed the large layer-control section from the left panel.
   - Folium layer control is collapsed by default.
   - Layer control is positioned at the top-right corner of the map.
   - Layer control CSS is compacted for a smaller footprint.

No backend analysis modules were changed.
