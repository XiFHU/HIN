# Step 4 UI steps refactor

This version creates a deeper UI package:

```text
ui/steps/
  __init__.py
  roads.py
  signals.py
  corridors.py
  crashes.py
  results.py
  sliding_window.py
```

`ui/workflow_shared.py` is now only an orchestrator. The analysis modules are unchanged.

Recommended next cleanup: split `ui/steps/results.py` further into classification and downloads after testing this version.
