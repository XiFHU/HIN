Step 1 modular UI split

Files included:
- app.py: main Streamlit shell, helper functions, map functions, and single-map layout.
- ui/workflows.py: left-panel workflow UI moved out of app.py.
- ui/__init__.py: makes ui a Python package.

How to use:
1. Put the ui folder beside your main app.py.
2. Replace your old app script with this app.py, or rename it to your Streamlit entry file.
3. Keep your existing modules/ folder unchanged.

Next steps:
- Move make_map() into ui/map_view.py or modules/map_view.py.
- Move layer controls into ui/layer_manager.py.
