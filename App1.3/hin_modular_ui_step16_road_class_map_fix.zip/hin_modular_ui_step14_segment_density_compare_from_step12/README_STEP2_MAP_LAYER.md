Step 2 update

This version adds two separated UI support files:

ui/map_view.py
- contains Folium map utilities
- contains make_map()
- contains map cleaning/export helpers used by the app

ui/layer_manager.py
- contains grouped layer controls
- stores visibility in st.session_state['visible_layers']
- make_map() checks these layer settings through is_layer_visible()

Existing analysis modules are unchanged.
